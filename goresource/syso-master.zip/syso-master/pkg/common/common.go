// Package common provides common utilities used by syso tool.
package common
