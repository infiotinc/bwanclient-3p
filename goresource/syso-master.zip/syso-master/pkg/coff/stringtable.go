package coff

type _string struct {
	offset uint32
	b      []byte
}
